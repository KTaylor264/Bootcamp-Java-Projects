/**
 * 
 */
 
 function openDate()
{
	alert("This is the date template");
}

function openTime()
{
	alert("This is the time template");
}